#include "Leitura.h"

using std::fstream;
using std::ofstream;
using std::ifstream;
using std::ios;
using std::string;

